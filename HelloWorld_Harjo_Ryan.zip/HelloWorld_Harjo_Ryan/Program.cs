﻿namespace HelloWorld_Harjo_Ryan
{
    internal class Program
    {
        static void Main(string[] args)
        {
            

            
            Console.Write("enter your first name: ");   // This displays a prompt asking for the user’s first name.
            string firstName = Console.ReadLine();   // This reads the user’s input (first name) and stores it in the firstName variable.


            Console.Write("enter your last name: ");   // This prompts asks the user for their last name.
            string lastName = Console.ReadLine();   // This reads the user’s input (last name) and stores it in the lastName variable.


            Console.WriteLine($"Hello, {firstName} {lastName}!");   // This outputs a greeting, combining the first and last name into the message using string interpolation.


        }
    }
}
